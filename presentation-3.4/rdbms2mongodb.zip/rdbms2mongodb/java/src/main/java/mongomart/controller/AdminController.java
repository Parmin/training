package mongomart.controller;

import java.sql.Connection;

import freemarker.template.Configuration;

/**
 * MongoMart admin page controller
 */
public class AdminController {
    private Configuration configuration;

    public AdminController(Configuration cfg, Connection connection) {
        // Add MongoMArt admin pages here
    }
}
