Build: mvn package

Run: java -jar ./target/MongoMart-1.0-SNAPSHOT.jar
