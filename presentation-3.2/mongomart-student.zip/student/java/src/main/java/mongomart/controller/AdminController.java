package mongomart.controller;

import com.mongodb.client.MongoDatabase;
import freemarker.template.Configuration;

/**
 * MongoMart admin page controller
 */
public class AdminController {
    private Configuration configuration;

    public AdminController(Configuration cfg, MongoDatabase itemDatabase) {
        // Add MongoMArt admin pages here
    }
}
