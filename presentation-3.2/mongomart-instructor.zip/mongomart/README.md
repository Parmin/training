Welcome to MongoMart
====================

Only items in the /student folder should be distributed to students

All answers and solutions are in the /instructor folder
