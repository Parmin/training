Lab 2 Solution
==============

Please type in solution with the class instead of distributing source code.

- Walk through each DAO method and ask the students how they solved the problem
- Use the student code as your base
- Type in the answer within each DAO method